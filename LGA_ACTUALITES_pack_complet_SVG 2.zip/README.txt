Pack SVG complet - Page ACTUALITÉS LGA

Tous les fichiers sont des découpes exactes de la maquette PNG fournie, encapsulées en SVG.
Important : la maquette d'origine est aplatie. Le personnage, la voiture, la fumée et certains décors se chevauchent.
Les SVG conservent donc exactement les pixels visibles dans chaque zone, mais ne sont pas des calques détourés transparents parfaits.
Le menu n'est volontairement pas inclus comme image : il doit rester identique à celui de la page ACCUEIL via le même HTML/CSS.
